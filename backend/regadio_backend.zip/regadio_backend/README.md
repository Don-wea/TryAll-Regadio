## Aplicar migraciones

python manage.py migrate


## Arrancar servidor

python manage.py runserver